#!/bin/bash
source venv/bin/activate
python bot/main.py
