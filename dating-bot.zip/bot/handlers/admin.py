from aiogram import Router, types
from bot.config import ADMIN_IDS

router = Router()

@router.message(lambda msg: msg.from_user.id in ADMIN_IDS and msg.text.lower().startswith("/broadcast"))
async def broadcast(message: types.Message):
    text = message.text.split(" ", 1)[1] if " " in message.text else ""
    if not text:
        await message.answer("❗ Please provide a message to broadcast.")
        return

    from bot.database.models import DB_PATH
    import aiosqlite

    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT id FROM users") as cursor:
            users = await cursor.fetchall()

    count = 0
    for (user_id,) in users:
        try:
            await message.bot.send_message(user_id, text)
            count += 1
        except:
            continue

    await message.answer(f"✅ Broadcast sent to {count} users.")
